{{/*
Expand the name of the chart.
*/}}
{{- define "nofire-edge.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "nofire-edge.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "nofire-edge.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "nofire-edge.labels" -}}
helm.sh/chart: {{ include "nofire-edge.chart" . }}
{{ include "nofire-edge.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "nofire-edge.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nofire-edge.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "nofire-edge.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "nofire-edge.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the image string
*/}}
{{- define "nofire-edge.image" -}}
{{- printf "%s:%s" .Values.image.repository (.Values.image.tag | default .Chart.AppVersion) }}
{{- end }}

{{/*
Create config name
*/}}
{{- define "nofire-edge.configName" -}}
{{- printf "%s-config" (include "nofire-edge.fullname" .) }}
{{- end }}

{{/*
Create ServiceMonitor namespace
*/}}
{{- define "nofire-edge.serviceMonitorNamespace" -}}
{{- if .Values.monitoring.serviceMonitor.namespace }}
{{- .Values.monitoring.serviceMonitor.namespace }}
{{- else }}
{{- .Release.Namespace }}
{{- end }}
{{- end }}

{{/*
Edge Proxy: fully qualified app name
*/}}
{{- define "nofire-edge.edgeProxy.fullname" -}}
{{- printf "%s-edge-proxy" (include "nofire-edge.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Edge Proxy: common labels
*/}}
{{- define "nofire-edge.edgeProxy.labels" -}}
helm.sh/chart: {{ include "nofire-edge.chart" . }}
{{ include "nofire-edge.edgeProxy.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Edge Proxy: selector labels
*/}}
{{- define "nofire-edge.edgeProxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "nofire-edge.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: edge-proxy
{{- end }}

{{/*
Edge Proxy: image string
*/}}
{{- define "nofire-edge.edgeProxy.image" -}}
{{- $repo := .Values.edgeProxy.image.repository | default "edge-proxy" -}}
{{- $tag := .Values.edgeProxy.image.tag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
Edge Proxy: service account name
*/}}
{{- define "nofire-edge.edgeProxy.serviceAccountName" -}}
{{- include "nofire-edge.edgeProxy.fullname" . }}
{{- end }}

{{/*
Edge Proxy: configmap name
*/}}
{{- define "nofire-edge.edgeProxy.configName" -}}
{{- printf "%s-config" (include "nofire-edge.edgeProxy.fullname" .) }}
{{- end }}